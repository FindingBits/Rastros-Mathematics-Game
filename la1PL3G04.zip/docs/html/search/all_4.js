var searchData=
[
  ['jogada_6',['JOGADA',['../struct_j_o_g_a_d_a.html',1,'']]],
  ['jogar_7',['jogar',['../logica_8h.html#a53472e75f056ceb02b5387193021838a',1,'logica.c']]],
  ['jogarauto_8',['jogarAuto',['../logica_8h.html#ac21f1755091edaf5e6282c985bd0cbf0',1,'logica.c']]],
  ['jogarautoadv_9',['jogarAutoAdv',['../logica_8h.html#a0115f90519ec7208cca17f8f6c47b53c',1,'logica.c']]]
];
