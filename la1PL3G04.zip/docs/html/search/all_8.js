var searchData=
[
  ['updatejogadas_15',['updateJogadas',['../logica_8h.html#a53460d878207187f17ea805973f7b9b5',1,'logica.c']]]
];
