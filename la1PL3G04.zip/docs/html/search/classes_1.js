var searchData=
[
  ['estado_17',['ESTADO',['../struct_e_s_t_a_d_o.html',1,'']]]
];
