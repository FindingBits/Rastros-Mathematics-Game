var searchData=
[
  ['entrada_22',['entrada',['../interface_8h.html#a50c45fa85652567c26f7a979e83a7a88',1,'interface.c']]]
];
