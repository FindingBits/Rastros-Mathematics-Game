var searchData=
[
  ['lista_10',['LISTA',['../struct_l_i_s_t_a.html',1,'']]],
  ['logica_2eh_11',['logica.h',['../logica_8h.html',1,'']]]
];
