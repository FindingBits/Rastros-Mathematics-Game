var searchData=
[
  ['logica_2eh_21',['logica.h',['../logica_8h.html',1,'']]]
];
