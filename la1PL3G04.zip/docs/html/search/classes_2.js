var searchData=
[
  ['jogada_18',['JOGADA',['../struct_j_o_g_a_d_a.html',1,'']]]
];
