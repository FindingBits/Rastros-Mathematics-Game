var searchData=
[
  ['entrada_1',['entrada',['../interface_8h.html#a50c45fa85652567c26f7a979e83a7a88',1,'interface.c']]],
  ['estado_2',['ESTADO',['../struct_e_s_t_a_d_o.html',1,'']]]
];
