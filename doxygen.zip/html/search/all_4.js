var searchData=
[
  ['jogada_6',['JOGADA',['../struct_j_o_g_a_d_a.html',1,'']]],
  ['jogar_7',['jogar',['../logica_8h.html#a53472e75f056ceb02b5387193021838a',1,'logica.c']]]
];
