var searchData=
[
  ['logica_2eh_17',['logica.h',['../logica_8h.html',1,'']]]
];
