var searchData=
[
  ['pedir_5fentrada_23',['pedir_entrada',['../interface_8h.html#a111f646229e0a9b01b86ae9048ce6677',1,'interface.c']]],
  ['podejogar_24',['podeJogar',['../logica_8h.html#ad08244b6e6e2b23a3c3459bb7b1413dd',1,'logica.h']]]
];
