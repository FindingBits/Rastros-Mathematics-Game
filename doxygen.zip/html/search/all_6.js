var searchData=
[
  ['mostrar_5ftabuleiro_10',['mostrar_tabuleiro',['../interface_8h.html#aa0b6c1689e60ac852a73d67e066c1df5',1,'interface.c']]]
];
