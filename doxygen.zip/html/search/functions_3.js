var searchData=
[
  ['jogar_21',['jogar',['../logica_8h.html#a53472e75f056ceb02b5387193021838a',1,'logica.c']]]
];
